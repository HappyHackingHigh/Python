import SelectionSort 

lst = [3, 4, 1, 2, 0]
SelectionSort.selectionSort(lst)
print(lst)